package com.hasib.petzone;

public enum UserType {
    ADMIN, CUSTOMER
}
