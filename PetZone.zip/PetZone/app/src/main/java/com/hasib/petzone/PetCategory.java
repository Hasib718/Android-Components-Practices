package com.hasib.petzone;

public enum PetCategory {
    CAT, DOG
}
